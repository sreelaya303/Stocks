package model;

import java.io.IOException;
import java.time.LocalDate;

public interface AlphaVantageApi {
  public float getStockPrice(String ticker, LocalDate date) throws IOException;
  public boolean checkTicker(String ticker);

  public boolean checkDate(LocalDate date);

}
