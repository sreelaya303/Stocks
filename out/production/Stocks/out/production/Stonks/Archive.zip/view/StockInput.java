package view;

public class StockInput {
  public void userInput(){}
}
