package view;

public enum Options {
  WRONG_OPTION("Sorry that was a wrong input, please try again :-)"),
  CREATE_LOAD("Press (1) if you want to create a new portfolio," +
          " Press (2) if you want to load an existing portfolio, Press EXIT to quit."),
  EXIT("Thank you for using stock analyzer 3000"),
  START("Welcome to stock analyzer 3000!"),

  CREAT_START("Let's build your new portfolio"),
  LOAD_START("Let's load your existing portfolio"),
  CREATE("Press (1) to add a new stock to your portfolio," +
          " Press (2) to save portfolio, Press EXIT to quit"),
  LOAD("Please provide the filepath to you existing portfolio:"),
  CREATE_SUCCESS("The portfolio has been successfully created, " +
          "Please load the created file to analyse the portfolio."),
  STOCK_TICKER("Enter stock ticker: "),
  STOCK_ENTRY_PRICE("Enter the stock entry price:"),
  STOCK_PURCHASE_DATE("Enter the date the stock was purchased:"),
  STOCK_PRICE_OPTIONS("Press (1) to add sto")

  private final String message;
  Options(String message){
    this.message = message;
  }

  public void print(){
    System.out.println(this.message);
  }


}
