/**
 * Tests the API call for Alphavantage.
 */
public class MainTest {

}
