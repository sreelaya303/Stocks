package view;

import java.util.Scanner;

public class CreatePortfolio {

  private StockInput stockInput = new StockInput();
  private UserInputMain userInputMain = new UserInputMain();
  Scanner myObj = new Scanner(System.in);
  public void userInput(){
    Options.CREAT_START.print();
    Options.CREATE.print();
    boolean repeat=false;
    do{
      String choice = myObj.nextLine().replace(" ", "");
      switch (choice) {
        case "1":
          stockInput.userInput();
          repeat = true;
          break;
        case "2":
          // TO-DO persist to file
          Options.CREATE_SUCCESS.print();
          userInputMain.userInput();
          break;
        case "EXIT":
          // TO-DO
          Options.EXIT.print();
          repeat = false;
          break;
        default:
          Options.WRONG_OPTION.print();
          Options.CREATE_LOAD.print();
          repeat=true;
      }
    } while(repeat);
  }
}
