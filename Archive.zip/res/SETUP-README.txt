Please install the maven dependency: googlecode.json.simple.1.1.1 and set Java language to be at 11.

The main program when run gives proper instructions on how to proceed further. 

This program supports all the stocks and dates supported by AlphavantageAPI.

Created portfolios will be saved in src/model/Portfolios.

Caching of stocks is done by saving files in src/model/cash.

