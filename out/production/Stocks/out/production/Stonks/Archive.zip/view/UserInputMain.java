package view;
import java.util.Scanner;

import javax.swing.text.html.Option;

public class UserInputMain {
  Scanner myObj = new Scanner(System.in);
  private final CreatePortfolio createPortfolio = new CreatePortfolio();
  private final LoadPortfolio loadPortfolio = new LoadPortfolio();

  public void userInput(){
    Options.START.print();
    Options.CREATE_LOAD.print();
    boolean repeat=false;
    do{
      String choice = myObj.nextLine().replace(" ", "");
      switch (choice) {
        case "1":
          createPortfolio.userInput();
          break;
        case "2":
          loadPortfolio.userInput();
          break;
        case "EXIT":
          // TO-DO
          Options.EXIT.print();
          break;
        default:
          Options.WRONG_OPTION.print();
          Options.CREATE_LOAD.print();
          repeat=true;
      }
    } while(repeat);

  }

}
