package view;

import java.util.Scanner;

public class LoadPortfolio {
  public void userInput(){
    Scanner myObj = new Scanner(System.in);

    Options.LOAD_START.print();
    Options.LOAD.print();

    String file = myObj.nextLine();

    // to-do load file here.

    // if successful ask:
      // analyse composition
      // get value at certain date

    // else if file corrupted:
      // print try again

    // else invalid file path
      // print try again


  }
}
